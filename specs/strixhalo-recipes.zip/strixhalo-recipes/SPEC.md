# Strix Halo Recipes — Build Specification

## 0. What this is

A git repo of reproducible LLM-serving "recipes" for unified-memory Linux
boxes (Strix Halo class APUs first, but not hardcoded to them), plus tools
so an AI agent can search recipes, replicate one, run its tests, and submit
a signed-ish result — without a human doing any of the legwork, and without
trusting a single contributor's claim of success.

## 1. Goals

1. **Reproducibility over narrative.** A recipe pins exact backend commit,
   build flags, quant, launch command, and hardware target — not prose
   ("works great on my machine").
2. **Multi-OS from day one at the tooling layer**, even though the initial
   authors are on Arch-family (CachyOS). Debian/Ubuntu and Fedora must be
   first-class, detected automatically, not bolted on.
3. **Trust via multiplicity.** No recipe is "validated" because one commit
   says so. Status is *derived* from independent result records, never
   hand-set.
4. **Cheap for agents to search.** An agent should be able to find the
   right recipe in 1-2 tool calls against a flat index, not by reading
   hundreds of YAML files.
5. **Failures are data.** A recipe that OOMs or produces garbage output is
   committed with `status: failed` and a reason, so no one (agent or human)
   repeats the experiment blind.
6. **Lineage, not overwrite.** Improving a recipe creates a new version
   that declares its parent(s) (one or more — merges are allowed). History
   is never rewritten in place.
7. **Harness capability is part of the spec, not an afterthought.** A
   recipe records whether the resulting server exposes tool-calling, MCP
   compatibility, and vision — because a chat-only endpoint is considered
   an incomplete result for this project.

## 2. Non-goals

- Not a model-quality leaderboard (that's LMSYS/others' job). Scores here
  are about "does this recipe run, how fast, and does it retain the
  capabilities it claims" — not general model IQ.
- Not a package manager. We don't install llama.cpp/backends for the user;
  we record how *they* built/installed it.
- Not Windows/macOS in v1. Structured so it *could* be extended (see §6),
  but only Linux is in scope now.

## 3. Core objects (see FORMAT.md for full schema)

- **Recipe** (`recipes/<model-slug>/<id>-v<version>.yaml`): the pinned
  configuration. Has a `content_hash` over the reproducibility-relevant
  fields, independent of the human-facing semver `version`.
- **Result** (`results/<id>/<content_hash>/<run_id>.json`): one append-only
  record of one attempt to run one recipe on one machine. Never edited
  after submission.
- **Index** (`index.json`, generated, not hand-edited): flattened
  frontmatter of every recipe, for cheap search.
- **Leaderboard** (`LEADERBOARD.md`, generated): aggregate of results per
  recipe/content_hash.

## 4. OS abstraction requirement

`tools/probe.sh` MUST:
- Detect distro family from `/etc/os-release` (`ID`, `ID_LIKE`) and branch
  into `probe.d/<family>.sh` for anything package-manager-specific
  (ROCm version query, kernel package name, etc.). Families to ship in v1:
  `arch` (CachyOS/Arch/Manjaro), `debian` (Ubuntu/Debian/Pop), `fedora`
  (Fedora/RHEL/Nobara).
- Fall back to a generic path (raw `uname`, `/sys`, `/proc`) if the distro
  family is unrecognized, and clearly mark the probe as `family: unknown`
  rather than failing — so results from an unlisted distro are still
  accepted, just flagged.
- A new distro family is added by dropping a new `probe.d/<family>.sh`
  implementing the same 5 functions (`pkg_version`, `rocm_info`,
  `kernel_info`, `gpu_info`, `mem_info`) and a one-line registration in
  `probe.sh`. This is the intended PR shape for contributors/agents adding
  OS support — call this out in `SKILL.md` explicitly so agents know the
  extension point exists and don't hand-roll parsing elsewhere.

## 5. Trust rules (must be enforced in code, not just docs)

- `validate.py` recomputes `content_hash` from a recipe's reproducibility
  fields and rejects the recipe if the committed hash doesn't match —
  prevents silent drift between what's declared and what's pinned.
- `validate.py` also rejects any recipe file where `status` is
  `validated` but the recipe was *just* added/changed in the same PR with
  zero corresponding `results/` records at that `content_hash`. Status
  transitions to `validated`/`deprecated` only come from
  `leaderboard.py`'s derived output, never from a human/agent typing it
  into the YAML directly. (`validate.py` treats a human-set `validated`
  as a lint warning to demote back to `experimental` until results exist.)
- `leaderboard.py` requires results from **≥2 distinct `contributor_id`
  values** at the same `content_hash` before a recipe counts as
  cross-validated. One person running it three times is still "1 witness."

## 6. Extensibility checkpoints

Build and land in this order so each checkpoint is independently useful
and testable by a different agent picking up from the previous one:

- **Checkpoint 1 — Schema + validator.** `schema/recipe.schema.json`,
  `schema/result.schema.json`, `tools/validate.py`. Done when: a hand-written
  example recipe + result validate cleanly, and a deliberately broken one
  (bad hash, missing required field) fails with a clear message.
- **Checkpoint 2 — Probe.** `tools/probe.sh` + `tools/probe.d/*.sh`. Done
  when: it runs cleanly on at least one real Arch-family box and produces
  the JSON shape `result.schema.json` expects under `probe_output`, and
  degrades to `family: unknown` without crashing on an unrecognized distro
  (test by faking `/etc/os-release`).
- **Checkpoint 3 — Submit + index + search.** `tools/submit_result.py`,
  `tools/build_index.py`, `tools/search.py`. Done when: submitting a result
  for a nonexistent recipe/hash is rejected; `search.py --model X
  --tool-calling --status validated` returns correct matches against a
  fixture set of 5+ recipes without loading full YAML bodies.
- **Checkpoint 4 — Leaderboard.** `tools/leaderboard.py`. Done when: given
  a fixture `results/` tree with 1 witness on recipe A and 2+ distinct
  witnesses on recipe B, output correctly marks only B as validated and
  shows median tok/s, pass rate, staleness per recipe.
- **Checkpoint 5 — SKILL.md + CI.** Agent-facing instructions + a GitHub
  Action that runs `validate.py` and `build_index.py` on every PR touching
  `recipes/` or `results/`. Done when: a PR that adds a recipe with a
  mismatched hash fails CI with the exact reason.
- **Checkpoint 5.5 — Collect tool.** `tools/collect.py` +
  `tools/gguf_lite.py`. Done when: pointed at a running llama-server (via
  `--pid` or `--launch-cmd`) it produces a schema-valid draft recipe with
  a correct `content_hash` and all of `model.source`, `model.quant`,
  `hardware.target`, `backend.commit`, and every
  `harness_compat.capabilities_confirmed` value left as an explicit
  placeholder/`false` rather than guessed — i.e. it never fabricates a
  tested capability. This checkpoint doubles as the acceptance test for
  "can a different agent operate this tooling": hand a fresh agent
  session only `SKILL.md` and a running server, and confirm it produces
  a submittable recipe without narration or hand-holding.
- **Checkpoint 6 (stretch) — Second OS family PR.** Have a different agent
  (or the same agent playing that role) add `probe.d/debian.sh` purely by
  reading `SPEC.md` §4 and `probe.d/arch.sh` as a template, with no other
  guidance, to validate the extension point actually works blind.

## 7. What "done" looks like for v1

- Two real recipes committed from your current CachyOS box (one per model
  you're already running), each with at least one real `results/` record
  from an actual run.
- `search.py` and `leaderboard.py` runnable with zero arguments beyond
  `--help` and producing sane output against those two recipes.
- `SKILL.md` such that a fresh agent session, given only this repo and the
  skill, can: find a recipe for a stated goal, replicate it, run its
  tests, and submit a result — without you narrating each step.
