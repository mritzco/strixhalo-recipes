# Recipe & Result Format

Canonical machine schemas are in `schema/recipe.schema.json` and
`schema/result.schema.json`. This doc explains the *why* and the
versioning/lineage rules; the JSON Schema is the source of truth for
validation.

## Two IDs, two purposes

- **`version`** (semver, e.g. `2.1.0`): human-facing. Bump PATCH for typo/doc
  fixes, MINOR for tuning that doesn't change what's pinned enough to
  matter to a casual reader, MAJOR for a different model/quant/backend.
  Not trusted for reproducibility.
- **`content_hash`** (`sha256:` of a canonical JSON serialization of the
  fields listed in `schema/recipe.schema.json`'s `"hashed_fields"` list —
  currently `model`, `backend`, `launch.command`, `hardware`): the actual
  reproducibility key. Results attach to a `content_hash`, not a `version`.
  If you change the launch command, the hash changes even if you forget to
  bump `version` — `validate.py` computes and checks this for you, you
  never hand-compute it.

This split exists so editing prose (adding a note, fixing a typo in
`rationale`) doesn't orphan existing results, but any change that could
affect whether the recipe actually runs the same way does.

## Lineage

`lineage.parents` is a list (not a single field) because recipes are
allowed to merge:

```yaml
lineage:
  parents:
    - id: qwen3.5-235b-baseline
      version: 1.4.0
      contribution: "base quant + sampler settings"
    - id: glm4.6-context-tuning
      version: 3.0.1
      contribution: "KV cache quant strategy for long context"
  rationale: "merged GLM's cache strategy onto the Qwen3.5 base"
```

Each parent entry pins the parent's `version` at time of merge (not just
`id`), so lineage is walkable even after the parent itself moves on to a
new version. `lineage.parents` is empty (`[]`) only for a true root recipe
(first recipe for a model with no prior art in this repo).

A recipe with no lineage claiming to be a trivial variant of an existing
one is a validate.py lint warning, not a hard error — sometimes independent
discovery happens — but reviewers should ask for it.

## Status field

`status` is one of `experimental | validated | deprecated | failed`.

- New recipes are always committed as `experimental`.
- `validated` is **only** ever written by `leaderboard.py` re-generating
  the recipe's status field as part of its run (it patches just that one
  field via a bot commit, or — simpler for v1 — outputs a side-table in
  `LEADERBOARD.md` and the recipe file itself always stays `experimental`
  in git; treat `LEADERBOARD.md` as the actual source of current trust
  status, not the YAML). Pick one and be consistent — v1 default: YAML
  stays `experimental`/`failed`/`deprecated` (author-set, honest about
  intent), and cross-validation status lives only in generated
  `LEADERBOARD.md` / `index.json`. This avoids bot-commit complexity in v1.
- `failed` is author-set when the author's own attempt failed. Still a
  full recipe file — see below.
- `deprecated` is author- or maintainer-set when a better recipe supersedes
  this one (should reference the successor via `lineage` on the *new*
  recipe pointing back, not a forward pointer here).

## Failed recipes

Same schema, same directory (`recipes/<model>/<id>-v<version>.yaml`), with:

```yaml
status: failed
failure_notes: "OOM at ctx>96k with --cache-type-k q8_0; works at q4_0 but recall drops to 0.6"
```

`tests` may be omitted or partial. Failed recipes are included in
`index.json` and searchable; `search.py` defaults to *including* them
(the point is agents see them) but supports `--exclude-failed` for when
someone specifically wants only runnable options.

## Result records

One JSON file per submission, named `<run_id>.json`, immutable once
written (never edit — submit a new run if you need to correct something,
and note the correction in `notes`). `run_id` is `<UTC-ISO8601>-<8charhex>`.

Path: `results/<recipe_id>/<content_hash-without-"sha256:"-prefix>/<run_id>.json`

Keying results by `content_hash` rather than `version` means a recipe
author can bump `version` for doc changes freely without splitting the
evidence trail; it only splits when something reproducibility-relevant
actually changed, which is exactly when it should split.

## Harness/capability fields are mandatory, not optional extras

`harness_compat.capabilities_confirmed` must explicitly list
`tools: true/false`, `mcp: true/false`, `vision: true/false` — not omitted.
The schema requires all three keys present (value can be `false`) so an
agent scanning `index.json` never has to treat "missing" as "false" by
convention; it's always stated.
