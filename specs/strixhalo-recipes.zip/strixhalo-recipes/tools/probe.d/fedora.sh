#!/usr/bin/env bash
# Fedora-family module (Fedora, RHEL, Nobara, CentOS).
# Status: community-contributed, please open a PR with corrections/results
# from a real box — this was written from documentation, not tested here.

family_pkg_version() {
  local pkg="$1"
  rpm -q --qf '%{VERSION}-%{RELEASE}' "$pkg" 2>/dev/null
}

family_rocm_info() {
  local v
  v="$(rpm -q --qf '%{VERSION}' rocm-core 2>/dev/null)"
  if [ -z "$v" ] && command -v rocminfo >/dev/null 2>&1; then
    v="$(rocminfo 2>/dev/null | grep -m1 -i 'ROCm Version' | awk -F: '{print $2}' | xargs)"
  fi
  echo "$v"
}

family_kernel_info() {
  uname -r
}

family_gpu_info() {
  if command -v lspci >/dev/null 2>&1; then
    lspci -mm 2>/dev/null | grep -i -E 'VGA|3D|Display' | head -1 | sed 's/"//g'
  else
    echo "unknown"
  fi
}

family_mem_info_gb() {
  awk '/MemTotal/ {printf "%.1f", $2/1024/1024}' /proc/meminfo
}
