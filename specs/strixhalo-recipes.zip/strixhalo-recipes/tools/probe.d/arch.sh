#!/usr/bin/env bash
# Arch-family module (Arch, CachyOS, Manjaro, EndeavourOS).
# Reference implementation — copy this file to add a new distro family.
# Required function names: family_pkg_version, family_rocm_info,
# family_kernel_info, family_gpu_info, family_mem_info_gb.
# Any you omit falls back to the generic implementation in probe.sh.

family_pkg_version() {
  local pkg="$1"
  pacman -Q "$pkg" 2>/dev/null | awk '{print $2}'
}

family_rocm_info() {
  local v
  v="$(pacman -Q rocm-core 2>/dev/null | awk '{print $2}')"
  if [ -z "$v" ] && command -v rocminfo >/dev/null 2>&1; then
    v="$(rocminfo 2>/dev/null | grep -m1 -i 'ROCm Version' | awk -F: '{print $2}' | xargs)"
  fi
  echo "$v"
}

family_kernel_info() {
  # CachyOS kernel packages carry useful suffixes (e.g. linux-cachyos)
  local pkg
  pkg="$(pacman -Q 2>/dev/null | grep -m1 -E '^linux(-cachyos|-zen|-lts)? ')"
  if [ -n "$pkg" ]; then
    echo "$pkg ($(uname -r))"
  else
    uname -r
  fi
}

family_gpu_info() {
  if command -v lspci >/dev/null 2>&1; then
    lspci -mm 2>/dev/null | grep -i -E 'VGA|3D|Display' | head -1 | sed 's/"//g'
  else
    echo "unknown"
  fi
}

family_mem_info_gb() {
  awk '/MemTotal/ {printf "%.1f", $2/1024/1024}' /proc/meminfo
}
