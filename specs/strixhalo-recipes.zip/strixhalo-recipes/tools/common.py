"""Shared helpers for the recipe tooling. Stdlib only, plus PyYAML+jsonschema."""
import hashlib
import json
import os
from pathlib import Path

import yaml

REPO_ROOT = Path(__file__).resolve().parent.parent
RECIPES_DIR = REPO_ROOT / "recipes"
RESULTS_DIR = REPO_ROOT / "results"
SCHEMA_DIR = REPO_ROOT / "schema"
INDEX_PATH = REPO_ROOT / "index.json"


def load_yaml(path):
    with open(path, "r") as f:
        return yaml.safe_load(f)


def canonical_json(obj):
    """Deterministic JSON: sorted keys, no whitespace ambiguity."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def compute_content_hash(recipe, hashed_fields):
    """Hash only the fields declared reproducibility-relevant in the schema."""
    subset = {k: recipe.get(k) for k in hashed_fields}
    digest = hashlib.sha256(canonical_json(subset).encode("utf-8")).hexdigest()
    return f"sha256:{digest}"


def iter_recipe_files():
    if not RECIPES_DIR.exists():
        return
    for path in sorted(RECIPES_DIR.rglob("*.yaml")):
        yield path


def iter_result_files():
    if not RESULTS_DIR.exists():
        return
    for path in sorted(RESULTS_DIR.rglob("*.json")):
        yield path


def load_schema(name):
    with open(SCHEMA_DIR / name, "r") as f:
        return json.load(f)
