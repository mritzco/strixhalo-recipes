#!/usr/bin/env bash
# probe.sh — collect a JSON fingerprint of this machine's LLM-serving setup.
#
# Design: distro-specific logic lives in probe.d/<family>.sh. Each module
# must define these functions (see probe.d/arch.sh for the reference impl):
#   pkg_version <pkg>   -> prints installed version or empty string
#   rocm_info             -> prints ROCm version or empty string
#   kernel_info           -> prints kernel release string
#   gpu_info              -> prints a short GPU description string
#   mem_info_gb           -> prints total RAM in GB (integer or float)
#
# Adding a new distro: copy probe.d/arch.sh, adjust the pkg-manager calls,
# register the family below in `detect_family`. That's the whole PR.
#
# Unrecognized distros still get a probe: family=unknown, and the generic
# fallbacks (uname, /proc/meminfo, lspci) are used instead of failing.

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

detect_family() {
  local id="" id_like=""
  if [ -r /etc/os-release ]; then
    # shellcheck disable=SC1091
    . /etc/os-release
    id="${ID:-}"
    id_like="${ID_LIKE:-}"
  fi
  case "$id $id_like" in
    *arch*|*manjaro*|*cachyos*|*endeavouros*) echo "arch" ;;
    *debian*|*ubuntu*|*pop*|*mint*)           echo "debian" ;;
    *fedora*|*rhel*|*nobara*|*centos*)        echo "fedora" ;;
    *)                                        echo "unknown" ;;
  esac
}

FAMILY="$(detect_family)"
DISTRO_PRETTY="$( { . /etc/os-release 2>/dev/null; echo "${PRETTY_NAME:-unknown}"; } )"

# Generic fallbacks, used by "unknown" family or if a module omits a function.
generic_kernel_info() { uname -r; }
generic_mem_info_gb() {
  awk '/MemTotal/ {printf "%.1f", $2/1024/1024}' /proc/meminfo
}
generic_gpu_info() {
  if command -v lspci >/dev/null 2>&1; then
    lspci -mm 2>/dev/null | grep -i -E 'VGA|3D|Display' | head -1 | sed 's/"//g'
  else
    echo "unknown"
  fi
}
generic_rocm_info() {
  if command -v rocminfo >/dev/null 2>&1; then
    rocminfo 2>/dev/null | grep -m1 -i 'ROCm Version' | awk -F: '{print $2}' | xargs
  else
    echo ""
  fi
}
generic_pkg_version() { echo ""; }

# Load family module if present; its functions override the generic ones.
MODULE="$SCRIPT_DIR/probe.d/${FAMILY}.sh"
if [ -f "$MODULE" ]; then
  # shellcheck disable=SC1090
  source "$MODULE"
fi

kernel_info()    { declare -f family_kernel_info    >/dev/null && family_kernel_info    || generic_kernel_info; }
mem_info_gb()    { declare -f family_mem_info_gb    >/dev/null && family_mem_info_gb    || generic_mem_info_gb; }
gpu_info()       { declare -f family_gpu_info       >/dev/null && family_gpu_info       || generic_gpu_info; }
rocm_info()      { declare -f family_rocm_info      >/dev/null && family_rocm_info      || generic_rocm_info; }
pkg_version()    { declare -f family_pkg_version    >/dev/null && family_pkg_version "$1" || generic_pkg_version "$1"; }

vulkan_info() {
  if command -v vulkaninfo >/dev/null 2>&1; then
    vulkaninfo --summary 2>/dev/null | grep -m1 'apiVersion' | awk -F'=' '{print $2}' | xargs
  else
    echo ""
  fi
}

llama_server_version() {
  if command -v llama-server >/dev/null 2>&1; then
    llama-server --version 2>&1 | head -1
  else
    echo ""
  fi
}

llama_swap_models() {
  # Best-effort: look for a llama-swap config in common locations.
  for f in "$HOME/.config/llama-swap/config.yaml" /etc/llama-swap/config.yaml ./config.yaml; do
    if [ -f "$f" ]; then
      echo "$f"
      return
    fi
  done
  echo ""
}

TIMESTAMP="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

RAW_JSON=$(cat <<EOF
{
  "timestamp": "$TIMESTAMP",
  "family": "$FAMILY",
  "distro": "$DISTRO_PRETTY",
  "kernel": "$(kernel_info)",
  "mem_total_gb": $(mem_info_gb),
  "gpu": "$(gpu_info | sed 's/"/\\"/g')",
  "rocm_version": "$(rocm_info)",
  "vulkan_version": "$(vulkan_info)",
  "backend_version": "$(llama_server_version | sed 's/"/\\"/g')",
  "llama_swap_config": "$(llama_swap_models)"
}
EOF
)

RAW_HASH=$(echo -n "$RAW_JSON" | sha256sum | awk '{print $1}')

echo "$RAW_JSON" | python3 -c "
import json, sys
d = json.load(sys.stdin)
d['raw_hash'] = 'sha256:$RAW_HASH'
print(json.dumps(d, indent=2))
"
