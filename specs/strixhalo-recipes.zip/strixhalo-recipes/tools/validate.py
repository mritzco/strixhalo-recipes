#!/usr/bin/env python3
"""
Validate every recipe and result in the repo.

Checks performed on recipes:
  1. JSON Schema validity against schema/recipe.schema.json
  2. Declared content_hash matches a recomputed hash of the hashed_fields
  3. lineage.parents (if non-empty) reference recipe ids that exist somewhere
     in the repo (any version — parents may reference older/removed-from-HEAD
     versions is out of scope for v1, we only check the id exists at all)
  4. status: validated is flagged as a lint warning if there are zero
     results/ records at this recipe's content_hash (see FORMAT.md - v1
     policy is that YAML status should stay honest to the author's own
     experience; cross-validation truth lives in generated LEADERBOARD.md)
  5. status: failed should have a non-null failure_notes

Checks performed on results:
  1. JSON Schema validity against schema/result.schema.json
  2. recipe_id + content_hash must match an existing recipe file
  3. run_id must be unique across the whole results/ tree

Exit code is non-zero if any hard error is found (warnings don't fail CI
by default; pass --strict to fail on warnings too).
"""
import argparse
import sys

import jsonschema

from common import (
    compute_content_hash, iter_recipe_files, iter_result_files, load_schema,
    load_yaml,
)


def validate_recipes(strict):
    schema = load_schema("recipe.schema.json")
    hashed_fields = schema["hashed_fields"]
    errors, warnings = [], []
    known_ids = set()
    recipes = []

    for path in iter_recipe_files():
        try:
            recipe = load_yaml(path)
        except Exception as e:
            errors.append(f"{path}: failed to parse YAML: {e}")
            continue
        recipes.append((path, recipe))
        known_ids.add(recipe.get("id"))

    for path, recipe in recipes:
        try:
            jsonschema.validate(recipe, schema)
        except jsonschema.ValidationError as e:
            errors.append(f"{path}: schema error: {e.message}")
            continue

        expected_hash = compute_content_hash(recipe, hashed_fields)
        if recipe["content_hash"] != expected_hash:
            errors.append(
                f"{path}: content_hash mismatch. "
                f"declared={recipe['content_hash']} computed={expected_hash} "
                f"(did you change model/backend/launch/hardware without "
                f"recomputing the hash?)"
            )

        for parent in recipe.get("lineage", {}).get("parents", []):
            if parent["id"] not in known_ids:
                warnings.append(
                    f"{path}: lineage parent '{parent['id']}' not found "
                    f"anywhere in recipes/ (renamed or typo?)"
                )

        if recipe["status"] == "validated":
            warnings.append(
                f"{path}: status is 'validated' in YAML. Per FORMAT.md v1 "
                f"policy this should normally stay 'experimental' — "
                f"cross-validated status belongs in generated LEADERBOARD.md, "
                f"not hand-set here."
            )

        if recipe["status"] == "failed" and not recipe.get("failure_notes"):
            errors.append(f"{path}: status is 'failed' but failure_notes is empty.")

    return errors, warnings, recipes


def validate_results(strict, recipes):
    schema = load_schema("result.schema.json")
    known = {}
    for path, recipe in recipes:
        known.setdefault(recipe["id"], set()).add(recipe["content_hash"])

    errors, warnings = [], []
    seen_run_ids = set()

    for path in iter_result_files():
        try:
            result = load_yaml(path)  # JSON is valid YAML
        except Exception as e:
            errors.append(f"{path}: failed to parse: {e}")
            continue
        try:
            jsonschema.validate(result, schema)
        except jsonschema.ValidationError as e:
            errors.append(f"{path}: schema error: {e.message}")
            continue

        rid, chash, run_id = result["recipe_id"], result["content_hash"], result["run_id"]
        if rid not in known:
            errors.append(f"{path}: recipe_id '{rid}' does not exist in recipes/")
        elif chash not in known[rid]:
            errors.append(
                f"{path}: content_hash '{chash}' does not match any known "
                f"version of recipe '{rid}' (stale result after an edit?)"
            )
        if run_id in seen_run_ids:
            errors.append(f"{path}: duplicate run_id '{run_id}'")
        seen_run_ids.add(run_id)

    return errors, warnings


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--strict", action="store_true", help="treat warnings as errors")
    args = ap.parse_args()

    r_errors, r_warnings, recipes = validate_recipes(args.strict)
    res_errors, res_warnings = validate_results(args.strict, recipes)

    for w in r_warnings + res_warnings:
        print(f"WARN  {w}")
    for e in r_errors + res_errors:
        print(f"ERROR {e}")

    total_errors = len(r_errors) + len(res_errors)
    total_warnings = len(r_warnings) + len(res_warnings)
    print(f"\n{len(recipes)} recipe(s) checked, {total_errors} error(s), {total_warnings} warning(s).")

    if total_errors or (args.strict and total_warnings):
        sys.exit(1)


if __name__ == "__main__":
    main()
