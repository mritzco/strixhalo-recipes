#!/usr/bin/env python3
"""
Build and write a results/ record for one recipe run.

Typical agent flow:
  1. bash tools/probe.sh > /tmp/probe.json
  2. run the recipe's tests[], collect pass/fail + scores
  3. python tools/submit_result.py \
       --recipe qwen3.5-235b-glm-fusion \
       --probe /tmp/probe.json \
       --contributor <stable-pseudonymous-id> \
       --test mcp-tool-roundtrip=pass \
       --test 64k-context-recall=pass:0.94 \
       --pp 412 --tg 38 \
       --notes "stable for 3hr session"

This does NOT run the tests itself (tests are arbitrary scripts declared
in the recipe) — it only assembles and validates the resulting record so
nobody hand-writes non-conforming JSON.
"""
import argparse
import hashlib
import json
import secrets
import sys
from datetime import datetime, timezone

import jsonschema

from common import RESULTS_DIR, iter_recipe_files, load_schema, load_yaml

TOOL_VERSION = "submit_result.py@1.0.0"


def find_recipe(recipe_id):
    matches = []
    for path in iter_recipe_files():
        recipe = load_yaml(path)
        if recipe.get("id") == recipe_id:
            matches.append(recipe)
    if not matches:
        sys.exit(f"No recipe found with id '{recipe_id}'")
    # If multiple versions exist on disk, use the one with the highest version.
    matches.sort(key=lambda r: tuple(map(int, r["version"].split("."))))
    return matches[-1]


def parse_test_arg(s):
    # formats: "id=pass", "id=fail", "id=pass:0.94"
    id_part, _, rest = s.partition("=")
    result, _, score = rest.partition(":")
    entry = {"id": id_part, "result": result}
    if score:
        entry["score"] = float(score)
    return entry


def make_run_id():
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return f"{ts}-{secrets.token_hex(4)}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--recipe", required=True, help="recipe id")
    ap.add_argument("--probe", required=True, help="path to probe.sh JSON output")
    ap.add_argument("--contributor", required=True, help="stable pseudonymous id")
    ap.add_argument("--test", action="append", default=[], help="id=pass|fail[:score]")
    ap.add_argument("--pp", type=float, help="prompt-processing tok/s")
    ap.add_argument("--tg", type=float, help="token-generation tok/s")
    ap.add_argument("--notes", default="")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    recipe = find_recipe(args.recipe)

    with open(args.probe) as f:
        probe_raw = json.load(f)
    probe_output = {
        "family": probe_raw.get("family", "unknown"),
        "distro": probe_raw.get("distro", ""),
        "kernel": probe_raw.get("kernel", ""),
        "mem_total_gb": probe_raw.get("mem_total_gb", 0),
        "gpu": probe_raw.get("gpu", ""),
        "rocm_version": probe_raw.get("rocm_version", ""),
        "vulkan_version": probe_raw.get("vulkan_version", ""),
        "backend_version": probe_raw.get("backend_version", ""),
        "raw_hash": probe_raw.get("raw_hash", ""),
    }

    result = {
        "recipe_id": recipe["id"],
        "recipe_version": recipe["version"],
        "content_hash": recipe["content_hash"],
        "run_id": make_run_id(),
        "contributor_id": args.contributor,
        "probe_output": probe_output,
        "tests": [parse_test_arg(t) for t in args.test],
        "tool_version": TOOL_VERSION,
    }
    if args.pp is not None or args.tg is not None:
        result["tokens_per_sec"] = {}
        if args.pp is not None:
            result["tokens_per_sec"]["pp"] = args.pp
        if args.tg is not None:
            result["tokens_per_sec"]["tg"] = args.tg
    if args.notes:
        result["notes"] = args.notes

    schema = load_schema("result.schema.json")
    jsonschema.validate(result, schema)

    out_dir = RESULTS_DIR / recipe["id"] / recipe["content_hash"].replace("sha256:", "")
    out_path = out_dir / f"{result['run_id']}.json"

    if args.dry_run:
        print(json.dumps(result, indent=2))
        print(f"\n(dry run — would write to {out_path})")
        return

    out_dir.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(result, f, indent=2)
        f.write("\n")

    print(f"Wrote {out_path}")
    print("Next: git add/commit this file and open a PR (or push, per your repo's flow).")


if __name__ == "__main__":
    main()
