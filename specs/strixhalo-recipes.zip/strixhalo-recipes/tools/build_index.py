#!/usr/bin/env python3
"""
Flatten every recipe's key fields into a single index.json so agents can
search without loading full YAML bodies. Also folds in a lightweight
witness count per recipe from results/, so search can filter on
"has this actually been reproduced" without a separate leaderboard pass.
"""
import json
from collections import defaultdict

from common import INDEX_PATH, iter_recipe_files, iter_result_files, load_yaml


def count_witnesses():
    """content_hash -> set of distinct contributor_ids."""
    witnesses = defaultdict(set)
    for path in iter_result_files():
        try:
            result = load_yaml(path)
        except Exception:
            continue
        witnesses[result.get("content_hash")].add(result.get("contributor_id"))
    return witnesses


def main():
    witnesses = count_witnesses()
    entries = []

    for path in iter_recipe_files():
        try:
            r = load_yaml(path)
        except Exception as e:
            print(f"skipping unparsable {path}: {e}")
            continue

        entries.append({
            "id": r.get("id"),
            "version": r.get("version"),
            "content_hash": r.get("content_hash"),
            "status": r.get("status"),
            "model_name": r.get("model", {}).get("name"),
            "quant": r.get("model", {}).get("quant"),
            "size_gb": r.get("model", {}).get("size_gb"),
            "vision": r.get("model", {}).get("vision"),
            "tool_calling": r.get("model", {}).get("tool_calling"),
            "mtp": r.get("model", {}).get("mtp", False),
            "hardware_target": r.get("hardware", {}).get("target"),
            "min_ram_gb": r.get("hardware", {}).get("min_ram_gb"),
            "engine": r.get("backend", {}).get("engine"),
            "os_family": r.get("backend", {}).get("os_family"),
            "capabilities_confirmed": r.get("harness_compat", {}).get("capabilities_confirmed", {}),
            "exposes_as": r.get("harness_compat", {}).get("exposes_as"),
            "distinct_witnesses": len(witnesses.get(r.get("content_hash"), set())),
            "path": str(path),
        })

    with open(INDEX_PATH, "w") as f:
        json.dump(entries, f, indent=2)
        f.write("\n")

    print(f"Wrote {INDEX_PATH} with {len(entries)} recipe(s).")


if __name__ == "__main__":
    main()
