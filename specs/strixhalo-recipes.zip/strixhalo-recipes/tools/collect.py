#!/usr/bin/env python3
"""
Collect a running llama.cpp-style setup into a draft recipe YAML.

This exists so nobody hand-writes recipe boilerplate. It is deliberately
conservative: anything it cannot verify by direct inspection (harness
capabilities, test results, tool-calling behavior) is left as an explicit
TODO / false rather than guessed, because guessed capability fields are
worse than missing ones (see SKILL.md — capabilities_confirmed must
reflect what was actually tested).

Two ways to point it at a setup:
  --pid <pid>          inspect a running process's /proc/<pid>/cmdline
  --launch-cmd "<cmd>"  parse a launch command string directly (e.g.
                        pasted from shell history or a systemd unit)
If neither is given, it searches `ps aux` for a process matching
llama-server/llama-cpp/ollama and asks for confirmation if more than one
is found.

Usage:
  python tools/collect.py --launch-cmd "llama-server -m /models/x.gguf --ctx-size 65536 --flash-attn" \\
      --model-name qwen3.5-235b-quick --author myhandle

  python tools/collect.py --pid 12345 --model-name qwen3.5-235b-quick

Output: writes recipes/<slug>/<id>-v0.1.0.yaml (status: experimental) and
prints a checklist of what still needs manual verification before this
is submission-ready.
"""
import argparse
import os
import re
import subprocess
import sys
from datetime import date

import yaml

from common import RECIPES_DIR, load_schema, compute_content_hash
import gguf_lite


def find_llama_processes():
    try:
        out = subprocess.check_output(["ps", "aux"], text=True)
    except Exception:
        return []
    matches = []
    for line in out.splitlines():
        if re.search(r"llama-server|llama\.cpp|ollama serve", line):
            parts = line.split(None, 10)
            if len(parts) >= 11:
                matches.append({"pid": parts[1], "cmd": parts[10]})
    return matches


def read_cmdline_from_pid(pid):
    path = f"/proc/{pid}/cmdline"
    if not os.path.exists(path):
        sys.exit(f"No /proc/{pid}/cmdline — is this Linux, and does the process still exist?")
    with open(path, "rb") as f:
        raw = f.read()
    return " ".join(p for p in raw.decode("utf-8", errors="replace").split("\x00") if p)


def parse_launch_flags(cmd):
    """Extract the handful of flags recipes care about from a launch command string."""
    def flag(name, default=None):
        m = re.search(rf"{re.escape(name)}\s+(\S+)", cmd)
        return m.group(1) if m else default

    def has_flag(name):
        return bool(re.search(rf"(^|\s){re.escape(name)}(\s|$)", cmd))

    return {
        "model_path": flag("-m") or flag("--model"),
        "ctx_size": flag("--ctx-size") or flag("-c"),
        "cache_type_k": flag("--cache-type-k"),
        "cache_type_v": flag("--cache-type-v"),
        "flash_attn": has_flag("--flash-attn"),
        "jinja": has_flag("--jinja"),
        "host": flag("--host", "127.0.0.1"),
        "port": flag("--port", "8080"),
    }


def run_probe():
    probe_sh = os.path.join(os.path.dirname(__file__), "probe.sh")
    try:
        out = subprocess.check_output(["bash", probe_sh], text=True)
    except Exception as e:
        print(f"WARNING: probe.sh failed ({e}); backend/hardware fields will be placeholders.")
        return {}
    import json
    return json.loads(out)


def slugify(name):
    s = re.sub(r"[^a-z0-9.]+", "-", name.lower()).strip("-")
    return s


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--pid", help="PID of a running llama-server process to inspect")
    ap.add_argument("--launch-cmd", help="Launch command string to parse directly")
    ap.add_argument("--model-name", required=True, help="Short recipe id, e.g. qwen3.5-235b-quick")
    ap.add_argument("--author", default=os.environ.get("USER", "unknown"))
    ap.add_argument("--min-ram-gb", type=int, default=128)
    ap.add_argument("--gpu-mem-split-gb", type=int, default=None)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    if args.launch_cmd:
        cmd = args.launch_cmd
    elif args.pid:
        cmd = read_cmdline_from_pid(args.pid)
    else:
        candidates = find_llama_processes()
        if not candidates:
            sys.exit(
                "No running llama-server/ollama process found, and no --pid or "
                "--launch-cmd given. Pass one of those explicitly."
            )
        if len(candidates) > 1:
            print("Multiple candidate processes found — re-run with --pid to disambiguate:")
            for c in candidates:
                print(f"  pid={c['pid']}  {c['cmd'][:100]}")
            sys.exit(1)
        cmd = read_cmdline_from_pid(candidates[0]["pid"])
        print(f"Using process pid={candidates[0]['pid']}")

    flags = parse_launch_flags(cmd)
    print(f"Parsed launch command:\n  {cmd}\n")
    print(f"Extracted flags: {flags}\n")

    model_meta = {}
    size_gb = None
    if flags["model_path"] and os.path.exists(flags["model_path"]):
        try:
            model_meta = gguf_lite.summarize(flags["model_path"])
            size_gb = round(os.path.getsize(flags["model_path"]) / (1024 ** 3), 1)
            print(f"Read GGUF metadata: name={model_meta.get('name')} "
                  f"arch={model_meta.get('architecture')} size={size_gb}GB")
        except gguf_lite.GGUFParseError as e:
            print(f"WARNING: could not parse GGUF metadata ({e}); size/quant will be placeholders.")
    else:
        print("WARNING: model path not found on this machine (remote run or already unloaded); "
              "model.* fields will be placeholders you must fill in by hand.")

    probe = run_probe()

    recipe_id = slugify(args.model_name)
    today = date.today().isoformat()

    recipe = {
        "id": recipe_id,
        "version": "0.1.0",
        "content_hash": "sha256:" + "0" * 64,  # placeholder, corrected below
        "status": "experimental",
        "created": today,
        "author": args.author,
        "license": "CC0",
        "lineage": {"parents": [], "rationale": "Auto-collected draft — fill in if this descends from another recipe."},
        "model": {
            "name": model_meta.get("name") or "TODO-fill-in",
            "source": "TODO-fill-in (e.g. huggingface repo)",
            "quant": "TODO-fill-in (e.g. Q4_K_XL)",
            "file_sha256": "TODO-fill-in",
            "size_gb": size_gb if size_gb is not None else 0,
            "mtp": False,
            "vision": bool(model_meta.get("has_vision_tower", False)),
            "tool_calling": flags["jinja"] or False,  # heuristic only, verify by testing
        },
        "hardware": {
            "target": "TODO-fill-in (e.g. strix-halo-128gb-unified)",
            "gpu_mem_split_gb": args.gpu_mem_split_gb,
            "min_ram_gb": args.min_ram_gb,
        },
        "backend": {
            "engine": "llama.cpp",
            "commit": probe.get("backend_version", "TODO-fill-in"),
            "build_flags": [],
            "rocm_version": probe.get("rocm_version") or None,
            "vulkan_version": probe.get("vulkan_version") or None,
            "kernel": probe.get("kernel", "TODO-fill-in"),
            "os_family": probe.get("family", "unknown"),
        },
        "launch": {"command": cmd},
        "harness_compat": {
            "tested_with": [],
            "exposes_as": "TODO-fill-in",
            "capabilities_confirmed": {
                "tools": False,  # NEVER auto-true; must be verified by an actual tool-call test
                "mcp": False,
                "vision": False,
            },
        },
        "tests": [],
        "failure_notes": None,
    }

    schema = load_schema("recipe.schema.json")
    recipe["content_hash"] = compute_content_hash(recipe, schema["hashed_fields"])

    out_dir = RECIPES_DIR / recipe_id
    out_path = out_dir / f"{recipe_id}-v0.1.0.yaml"

    if args.dry_run:
        print("\n--- draft recipe (dry run, not written) ---\n")
        print(yaml.safe_dump(recipe, sort_keys=False))
        return

    out_dir.mkdir(parents=True, exist_ok=True)
    if out_path.exists():
        sys.exit(f"{out_path} already exists — bump the version or remove it first.")
    with open(out_path, "w") as f:
        yaml.safe_dump(recipe, f, sort_keys=False)

    print(f"\nWrote draft recipe: {out_path}")
    print("""
This is a DRAFT. Before proposing it as a PR, you must:
  [ ] Fill in model.source, model.quant, model.file_sha256 (sha256sum the .gguf)
  [ ] Fill in hardware.target
  [ ] Fill in backend.commit (llama-server --version) and backend.build_flags
  [ ] Actually test tool-calling, MCP round-trip, and vision if applicable,
      then set harness_compat.capabilities_confirmed truthfully (all three
      default to false here — a heuristic guess is NOT a substitute for
      testing one of them)
  [ ] Add real tests[] entries and run them
  [ ] Run: python tools/validate.py --strict
  [ ] Submit a results/ record with tools/submit_result.py once tested
""")


if __name__ == "__main__":
    main()
