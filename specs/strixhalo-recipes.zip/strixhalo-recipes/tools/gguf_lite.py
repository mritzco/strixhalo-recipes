"""
Minimal GGUF metadata reader. Reads only the header + key-value metadata
section of a .gguf file (not tensor data), so it's fast even on 100GB+
files. No external deps — GGUF is a documented binary format, this is a
straightforward struct reader.

Reference: https://github.com/ggml-org/ggml/blob/master/docs/gguf.md
"""
import struct

GGUF_MAGIC = b"GGUF"

# value type enum per spec
T_UINT8, T_INT8, T_UINT16, T_INT16, T_UINT32, T_INT32 = 0, 1, 2, 3, 4, 5
T_FLOAT32, T_BOOL, T_STRING, T_ARRAY, T_UINT64, T_INT64, T_FLOAT64 = 6, 7, 8, 9, 10, 11, 12

_SCALAR_FMT = {
    T_UINT8: "<B", T_INT8: "<b", T_UINT16: "<H", T_INT16: "<h",
    T_UINT32: "<I", T_INT32: "<i", T_FLOAT32: "<f", T_BOOL: "<?",
    T_UINT64: "<Q", T_INT64: "<q", T_FLOAT64: "<d",
}


class GGUFParseError(Exception):
    pass


def _read(f, n):
    data = f.read(n)
    if len(data) != n:
        raise GGUFParseError(f"unexpected EOF reading {n} bytes")
    return data


def _read_u32(f):
    return struct.unpack("<I", _read(f, 4))[0]


def _read_u64(f):
    return struct.unpack("<Q", _read(f, 8))[0]


def _read_string(f):
    length = _read_u64(f)
    return _read(f, length).decode("utf-8", errors="replace")


def _read_value(f, value_type):
    if value_type in _SCALAR_FMT:
        size = struct.calcsize(_SCALAR_FMT[value_type])
        return struct.unpack(_SCALAR_FMT[value_type], _read(f, size))[0]
    if value_type == T_STRING:
        return _read_string(f)
    if value_type == T_ARRAY:
        elem_type = _read_u32(f)
        count = _read_u64(f)
        return [_read_value(f, elem_type) for _ in range(count)]
    raise GGUFParseError(f"unknown value type {value_type}")


def read_metadata(path, max_kv=None):
    """
    Returns a dict of GGUF metadata key -> value, plus a few derived fields:
    _tensor_count, _gguf_version, _n_kv.

    Only reads the header + KV section; stops before tensor info/data, so
    this is safe and fast to run against very large model files.
    """
    meta = {}
    with open(path, "rb") as f:
        magic = _read(f, 4)
        if magic != GGUF_MAGIC:
            raise GGUFParseError(f"not a GGUF file (bad magic: {magic!r})")
        version = _read_u32(f)
        tensor_count = _read_u64(f)
        kv_count = _read_u64(f)

        meta["_gguf_version"] = version
        meta["_tensor_count"] = tensor_count
        meta["_n_kv"] = kv_count

        limit = kv_count if max_kv is None else min(kv_count, max_kv)
        for _ in range(limit):
            key = _read_string(f)
            value_type = _read_u32(f)
            try:
                value = _read_value(f, value_type)
            except GGUFParseError:
                # Unknown/nested type we don't support — stop metadata scan,
                # but return what we've got rather than failing the whole read.
                break
            meta[key] = value

    return meta


def summarize(path):
    """Best-effort extraction of the fields recipes care about."""
    meta = read_metadata(path)
    arch = meta.get("general.architecture", "")
    return {
        "name": meta.get("general.name") or meta.get(f"{arch}.name"),
        "architecture": arch or None,
        "quantization_version": meta.get("general.quantization_version"),
        "file_type": meta.get("general.file_type"),
        "context_length": meta.get(f"{arch}.context_length") if arch else None,
        "has_vision_tower": any(k.startswith(f"{arch}.vision.") for k in meta) if arch else False,
        "raw": meta,
    }
