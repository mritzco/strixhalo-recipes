# strixhalo-recipes

Reproducible LLM-serving recipes for unified-memory Linux boxes (Strix
Halo class APUs first), with lineage tracking and multi-witness trust —
built so an AI agent can search, replicate, test, and contribute results
with minimal token spend and without anyone having to trust a single
person's claimed win.

Start here:
- **`SPEC.md`** — goals, non-goals, and build checkpoints (for a human or
  agent building/extending this repo).
- **`FORMAT.md`** — full explanation of the recipe/result format,
  versioning, and lineage rules.
- **`SKILL.md`** — instructions for an agent using this repo day to day
  (search, replicate, submit, contribute).

## Quick start

```bash
pip install -r tools/requirements.txt

# see what's here
python tools/build_index.py
python tools/search.py --model qwen3

# validate everything (recipes + results)
python tools/validate.py --strict

# regenerate the human-readable leaderboard
python tools/leaderboard.py

# fingerprint this machine
bash tools/probe.sh > /tmp/probe.json

# turn a running server into a draft recipe (no hand-written YAML)
python tools/collect.py --pid $(pgrep -f llama-server) --model-name my-quick-test --dry-run
# drop --dry-run to actually write recipes/my-quick-test/my-quick-test-v0.1.0.yaml

# submit a result after running a recipe's tests
python tools/submit_result.py \
  --recipe qwen3.5-235b-baseline \
  --probe /tmp/probe.json \
  --contributor your-stable-pseudonym \
  --test mcp-tool-roundtrip=pass \
  --test 64k-context-recall=pass:0.94 \
  --pp 412 --tg 38
```

## Layout

```
schema/           JSON Schema for recipes and results (source of truth)
recipes/<model>/  One YAML file per recipe version
results/<id>/<hash>/  Append-only result records
tools/            probe.sh (+ probe.d/<distro>.sh), collect.py, gguf_lite.py,
                  validate.py, submit_result.py, build_index.py, search.py,
                  leaderboard.py
tests/            Test scripts referenced by recipes' tests[] fields
index.json        Generated — flattened recipe search index
LEADERBOARD.md    Generated — cross-validated status lives here, not in YAML
```

## Contributing an OS you use that isn't covered yet

See `SPEC.md` §4. Adding Debian/Fedora/whatever-else support is a single
new file in `tools/probe.d/` plus a one-line registration — no other code
changes needed. Stub `debian.sh` and `fedora.sh` modules are already
included but unverified; testing and fixing them against a real box is a
great first PR.
