---
name: strixhalo-recipes
description: Use when the user wants to run, replicate, benchmark, or contribute a local-LLM serving setup (llama.cpp/ollama/etc on unified-memory Linux hardware like Strix Halo). Covers finding an existing tested recipe, replicating it, running its tests, submitting results, and adding new recipes with proper lineage.
---

# strixhalo-recipes

A git repo of reproducible local-LLM serving recipes with lineage and
multi-witness trust. Full spec: `SPEC.md`. Field-by-field format: `FORMAT.md`.

## When the user wants to run a model

1. `python tools/build_index.py` if `index.json` looks stale or missing.
2. `python tools/search.py --model <name> [--tool-calling] [--vision] [--mcp] --hardware <target>`
   to find candidates. Read only the matching entries' full YAML
   (`recipes/<model>/<id>-v<version>.yaml`) — don't scan the whole
   `recipes/` tree.
3. Prefer recipes with `distinct_witnesses >= 2` over ones with 0-1. If
   the only options have 0 witnesses, say so explicitly before running.
4. Reproduce **exactly**: pull the pinned `backend.commit`, use
   `launch.command` verbatim, don't "improve" flags on the fly. If you
   want to try a variant, that's a *new* recipe with lineage back to this
   one — see below.
5. Run `bash tools/probe.sh > /tmp/probe.json` before/after to capture the
   environment.
6. Run the recipe's `tests[]` (each has a `script` field — run it, note
   pass/fail/score).
7. Submit: `python tools/submit_result.py --recipe <id> --probe /tmp/probe.json
   --contributor <stable-id-you-choose> --test <id>=pass[:score] ... --pp <n> --tg <n>`
   Then tell the user the exact `git add`/commit/PR steps — don't push
   without confirmation.

## When the user wants to try a new model/quant/flag combo

1. Search first (step 2 above) — don't duplicate an existing recipe.
2. **Use `tools/collect.py` to generate the draft, don't hand-write YAML.**
   If a server is already running:
   `python tools/collect.py --pid <pid> --model-name <slug> --author <you>`
   or point it at a launch command directly (e.g. from shell history):
   `python tools/collect.py --launch-cmd "llama-server -m ... --ctx-size ..." --model-name <slug>`
   This inspects the actual process/GGUF file and `probe.sh` output to fill
   in `model.*`, `backend.*`, `hardware.*`, and computes `content_hash`
   correctly by construction — it does not guess. It intentionally leaves
   `harness_compat.capabilities_confirmed` all `false` and several fields
   `TODO-fill-in`, because those require you to actually test, not infer.
   Run with `--dry-run` first to preview before it writes a file.
3. Work through the checklist `collect.py` prints at the end: fill in the
   `TODO-fill-in` fields (model source/quant/sha256, hardware target,
   backend commit), then actually exercise tool-calling / MCP / vision
   against the running server and set `capabilities_confirmed` truthfully,
   then add real `tests[]` entries.
4. Set `lineage.parents` to whatever recipe(s) you started from, with a
   one-line `contribution` per parent (`collect.py` can't know this —
   fill it in by hand if the setup descends from an existing recipe). If
   combining two unrelated recipes (e.g. one model's quant strategy +
   another's context-shifting flags), list both parents — this is
   expected and encouraged.
5. `status: experimental` always for a new recipe, even if it worked
   perfectly for you (this is `collect.py`'s default, don't change it).
   Cross-validated status is earned via witnesses, not declared.
6. If it failed: still commit it, `status: failed`, fill `failure_notes`
   with the actual error/OOM/behavior. This is as valuable as a success.
   (`collect.py` can still be used to capture the config that failed —
   just add `status: failed` and `failure_notes` after the fact.)
7. Run `python tools/validate.py` before proposing the PR. Fix every
   ERROR; warnings are worth mentioning to the user but not blocking.

## When the user wants to know what's actually good right now

Run `python tools/leaderboard.py` and read `LEADERBOARD.md` — this is the
only place "validated" status should be trusted from. A recipe's own YAML
`status: validated` (if you ever see one) should be treated with
suspicion; per `FORMAT.md` it shouldn't normally be hand-set.

## Adding support for a distro this repo doesn't cover yet

`tools/probe.d/<family>.sh` is the extension point — see `SPEC.md` §4.
Copy `tools/probe.d/arch.sh`, adapt the five `family_*` functions to the
target distro's package manager, register the family string in
`detect_family()` inside `tools/probe.sh`, and open a PR. You don't need
to touch anything else — `probe.sh`, `submit_result.py`, and the schemas
already handle an arbitrary `family` value.

## Hard rules (don't skip these even under time pressure)

- Never hand-set `content_hash` — always let `validate.py` tell you the
  correct value from the actual `model`/`backend`/`launch`/`hardware`
  fields.
- Never edit an existing file under `results/` — results are append-only.
  If a run needs correcting, submit a new one and explain in `notes`.
- Never write `status: validated` into a recipe YAML yourself.
- A recipe's `harness_compat.capabilities_confirmed` must reflect what you
  actually tested (tool calls, MCP round-trip, vision input) — don't copy
  it from a similar recipe without verifying, since this is the whole
  point of the project per the user's original ask: a recipe that only
  proves chat works is an incomplete recipe.
